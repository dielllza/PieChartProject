import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
/*PieChartWriter helps a user draw a pie chart of at most 6 "slices" */
public class PieChartWriter4 extends JPanel
{
  private int width=480; // the frame's width
  private int height=300; // the frame's height
  private int x = width/13; // the arc's topLeftX position
  private int y = height/10; // the arc's topLeftY position
  private int diameter =height-height/3; // the arc's width and height
  private int brinja_e_katrorit=height/20; // the rectangle's width and heigth 
  private double startAngle = 0; // used for calculating the sum of each previous startAngles of arcs
  private JFrame korniza = new JFrame();
  private double[] listaAmounts = {0,0,0,0,0,0}; //an array of double types of values
  private Color[] listaColors = {Color.black,Color.black,Color.black,Color.black,Color.black,Color.black}; //an array of Color type values
  private String[] listaLabels = {"","","","","",""}; //an array of String type values

/**Constructor PieChartWriter creates the window and makes it visible */
  public PieChartWriter4(){
  korniza.getContentPane().add(this);
  korniza.setSize(width,height);
  korniza.setVisible(true);
  }
  
  /**setTitle sets the title of the window
   *@param title- the title of the string*/
  public void setTitle(String title){
   korniza.setTitle(title);
  }
  
  /**paintComponent paints the panel and
  *@param g - the "Graphics pen" that draws and fills the items(strings,arcs,rectangles)
  */
  public void paintComponent(Graphics g){
  int largesia_x = x+diameter + height/12;
  int largesia_x_tekstit = largesia_x + brinja_e_katrorit+5;
  g.setColor(new Color(222,28,36));
  g.fillRect(0,0,width,height);
  g.setColor(new Color(255,255,204));
  g.fillRect(8,8,width-32,height-55);
  Graphics2D g2 = (Graphics2D) g; // creating new object of Grapgics2D by casting the "Graphics pen"
  for (int i = 0; i < listaAmounts.length; i++) {
     for (int j = 0; j < listaColors.length; j++) {
        if(i==j && i>0){
           g2.setPaint(listaColors[j]); //set the color of g2
           startAngle=startAngle + calculateArcAngle(listaAmounts[i-1]);
           g2.fill(new Arc2D.Double(x,y,diameter,diameter,startAngle,calculateArcAngle(listaAmounts[i]), Arc2D.PIE));//fill the arc
           g.fillRect(largesia_x,largesia_y(i+1),brinja_e_katrorit,brinja_e_katrorit);//fill the rectangle
       }else if (i==0 && j==0){
        g2.setPaint(listaColors[j]);
        g2.fill(new Arc2D.Double(x,y,diameter,diameter,0,calculateArcAngle(listaAmounts[i]), Arc2D.PIE));
        g.fillRect(largesia_x,largesia_y(i+1),brinja_e_katrorit,brinja_e_katrorit);
       }
     }
   }
   for(int i =0; i<listaLabels.length;i++){
   g.setColor(Color.black);
   g.setFont(new Font("Comic Sans MS", Font.PLAIN,diameter/12));
   int largesia_y_tekstit = largesia_y(i+1)+4*brinja_e_katrorit/5;
   g.drawString(listaLabels[i],largesia_x_tekstit,largesia_y_tekstit);
   }
  }
  
 /**total calculates the sum of amounts given as parameters to the setAmount method
  */ 
  private double total(){
  double totali =0;
  for (int i = 0; i < listaAmounts.length; i++) {
      totali += listaAmounts[i];}
      return totali;
      }
      
/**calculateArcAngle calculates the arc's angle
  *@param amount - the amount given as parameter to the setSlice methods
  */      
  private double calculateArcAngle(double amount)
  {
  return (amount*360.0)/total();
  }
  
   /**largesia_y calculates the topLeftY value of the rectangle to be drawn
  *@param z - the z-th rectangle  
  */
   private int largesia_y(int z){
   return y+(z*brinja_e_katrorit)+(z*3);
  }
  
  /**setLabels sets the texts to be printed to the right of the pie
  *@param s1 - the string that represents the first arc
  *@param s2 - the string that represents the second arc
  *@param s3 - the string that represents the third arc
  *@param s4 - the string that represents the fourth arc
  *@param s5 - the string that represents the fifth arc
  *@param s6 - the string that represents the sixth arc
  */
  public void setLabels(String s1,String s2,String s3,String s4,String s5,String s6){
  listaLabels[0]=s1; //replace the falue of listaLabels's first element to the value of s1
  listaLabels[1]=s2;
  listaLabels[2]=s3;
  listaLabels[3]=s4;
  listaLabels[4]=s5;
  listaLabels[5]=s6;
  }
  
  
  /**setAmounts sets the amounts of the slice to be be drawn
  *@param am1 - the amont of the first arc
  *@param am2 - the amont of the second arc
  *@param am3 - the amont of the third arc
  *@param am4 - the amont of the fourth arc
  *@param am5 - the amont of the fifth arc
  *@param am6 - the amont of the sixth arc
  */
  public void setAmounts(double am1,double am2,double am3,double am4,double am5,double am6){
  listaAmounts[0]=am1; //replace the falue of listaAmounts's first element to the value of am1
  listaAmounts[1]=am2;
  listaAmounts[2]=am3;
  listaAmounts[3]=am4;
  listaAmounts[4]=am5;
  listaAmounts[5]=am6;
  }
  
  /**setColors sets the colors of the arcs to be filled
  *@param ngj1 - the color of the first arc
  *@param ngj2 - the color of the second arc
  *@param ngj3 - the color of the third arc
  *@param ngj4 - the color of the fourth arc
  *@param ngj5 - the color of the fifth arc
  *@param ngj6 - the color of the sixth arc
  */
  public void setColors(Color ngj1,Color ngj2,Color ngj3,Color ngj4,Color ngj5,Color ngj6){
  listaColors[0]=ngj1; //replace the falue of listaColors's first element to the value of ngj1
  listaColors[1]=ngj2;
  listaColors[2]=ngj3;
  listaColors[3]=ngj4;
  listaColors[4]=ngj5;
  listaColors[5]=ngj6;
  }
}