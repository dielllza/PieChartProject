import java.awt.*;
public class Pie4{
 public static void main(String[] args)
 {
 PieChartWriter4 c = new PieChartWriter4();//a new object is constructed from class PieChartWriter 
 c.setTitle("Popullisa e botes");//the title that is shown in the window
 c.setLabels("Europa: 9.73%","Azia 59.55%","Afrika 16.87%","Amerika Veriore 7.7%","Amerika Jugore 5.61%","Oceania 0.54%");// the text of 6 slices
 c.setAmounts(9.73, 59.55, 16.7, 7.7, 5.61, 0.54);// the amount of 6 slices
 c.setColors(new Color(255,140,0),new Color(97,168,255),new Color(255,204,204),new Color(60,179,113),new Color(247,44,71),new Color(97,255,184));//the colors f 6 slices
 }}
