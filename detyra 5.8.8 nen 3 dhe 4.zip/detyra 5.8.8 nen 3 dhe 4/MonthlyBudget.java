import java.awt.*;
public class MonthlyBudget
{
public static void main(String[] args)
  {
   PieChartWriter c = new PieChartWriter();//a new object is constructed from class PieChartWriter 
   c.setTitle("Monthly Budget");//the title that is shown in the window
   c.setSlice1("Food: 150 �",150,new Color(247,44,71));// set the first slice's text,amount and color
   c.setSlice2("Electricity bill: 57 �",57,new Color(255,140,0));
   c.setSlice3("Water bill: 35 �",35,new Color(97,255,184));
   c.setSlice4("House rent: 300 �",300,new Color(255,204,204));
   c.setSlice5("Personal expenses: 200 �",200,new Color(97,168,255));
   c.setSlice6("Savings: 100 �",100,new Color(60,179,113));
   }
}