import java.awt.*;
import javax.swing.*;
public class PlanetMasses
{
public static void main(String[] args)
  {
   PieChartWriter c =  new PieChartWriter();//a new object is constructed from class PieChartWriter 
   c.setTitle("Masat e Paneteve"); //the title that is shown in the window
   c.setSlice1(" Merkuri: 0.05",0.05,new Color(55,140,0)); // set the first slice's text,amount and color
   c.setSlice2(" Venera: 0.81",0.81,new Color(255,255,102));
   c.setSlice3(" Toka: 1.00",1.00,new Color(97,255,184));
   c.setSlice4(" Marsi: 0.11",0.11,new Color(255,160,122));
   c.setSlice5(" Jupiteri: 318.4",318.4,new Color(250,78,62));
   c.setSlice6(" Saturni: 95.3",95.3,new Color(100,149,237));
   
  }
}