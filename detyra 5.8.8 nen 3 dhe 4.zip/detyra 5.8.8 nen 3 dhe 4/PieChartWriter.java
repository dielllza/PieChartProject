import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
/*PieChartWriter helps a user draw a pie chart of at most 6 "slices" */
public class PieChartWriter extends JPanel
{
  private int width=500; // the frame's width
  private int height=300; // the frame's height
  private int x = width/13; // the arc's topLeftX position
  private int y = height/10; // the arc's topLeftY position
  private int diameter =height-height/3; // the arc's width and height
  private int brinja_e_katrorit=height/20; // the rectangle's width and heigth

  private String label1 ="",label2 ="",label3 ="",label4 ="",label5 ="",label6 ="";
  
  private Color ngjyra1,ngjyra2,ngjyra3,ngjyra4,ngjyra5,ngjyra6;
  
  private double amount1,amount2,amount3,amount4,amount5,amount6;
  
  private double totalStartAngle=0; // used for calculating the sum of each previous startAngles of arcs
  private JFrame korniza = new JFrame();
 /**Constructor PieChartWriter creates the window and makes it visible */
  public PieChartWriter()
  {
  korniza.getContentPane().add(this);
  korniza.setSize(width,height);
  korniza.setVisible(true);
  }
  
  /**setTitle sets the title of the window
   *@param title- the title of the string*/
  public void setTitle(String title)
  {
   korniza.setTitle(title);
  }
  
  /**paintComponent paints the panel and
  *@param g - the "Graphics pen" that draws and fills the items(strings,arcs,rectangles)
  */
   public void paintComponent(Graphics g)
  {
  int largesia_x = x+diameter + height/12;
  int largesia_x_tekstit = largesia_x + brinja_e_katrorit+5;
  g.setColor(new Color(222,28,36));
  g.fillRect(0,0,width,height);
  g.setColor(new Color(255,255,204));
  g.fillRect(width/60,height/37,width-width/15,(height*61)/75);
  Graphics2D g2 = (Graphics2D) g; // creating new object of Grapgics2D by casting the "Graphics pen"

  g2.setPaint(ngjyra1); //set the color of the g2
  g2.fill(new Arc2D.Double(x,y,diameter,diameter,0,calculateArcAngle(amount1),Arc2D.PIE));//fill the arc with startAngle=0
  g.fillRect(largesia_x,largesia_y(1),brinja_e_katrorit,brinja_e_katrorit);
    
  g2.setPaint(ngjyra2);
  g2.fill(new Arc2D.Double(x,y,diameter,diameter,calculatestartAngle(amount1),calculateArcAngle(amount2), Arc2D.PIE));
  g.fillRect(largesia_x,largesia_y(2),brinja_e_katrorit,brinja_e_katrorit);
  
  g2.setPaint(ngjyra3);
  g2.fill(new Arc2D.Double(x,y,diameter,diameter,calculatestartAngle(amount2),calculateArcAngle(amount3), Arc2D.PIE));
  g.fillRect(largesia_x,largesia_y(3),brinja_e_katrorit,brinja_e_katrorit);
  
  g2.setPaint(ngjyra4);
  g2.fill(new Arc2D.Double(x,y,diameter,diameter,calculatestartAngle(amount3),calculateArcAngle(amount4), Arc2D.PIE));
  g.fillRect(largesia_x,largesia_y(4),brinja_e_katrorit,brinja_e_katrorit);
  
  g2.setPaint(ngjyra5);
  g2.fill(new Arc2D.Double(x,y,diameter,diameter,calculatestartAngle(amount4),calculateArcAngle(amount5), Arc2D.PIE));
  g.fillRect(largesia_x,largesia_y(5),brinja_e_katrorit,brinja_e_katrorit);
  
  g2.setPaint(ngjyra6);
  g2.fill(new Arc2D.Double(x,y,diameter,diameter,calculatestartAngle(amount5),calculateArcAngle(amount6), Arc2D.PIE));
  g.fillRect(largesia_x,largesia_y(6),brinja_e_katrorit,brinja_e_katrorit);

  g2.setPaint(Color.black);
  g.setFont(new Font("Comic Sans MS", Font.PLAIN,diameter/12)); //set the font of "Graphics pen" to "Comic Sans MS" with size ofdiameter/12 and PLAIN style
  g.drawString(label1,largesia_x_tekstit,largesia_y_teksti(1)); //draw the strings
  g.drawString(label2,largesia_x_tekstit,largesia_y_teksti(2));
  g.drawString(label3,largesia_x_tekstit,largesia_y_teksti(3));
  g.drawString(label4,largesia_x_tekstit,largesia_y_teksti(4));
  g.drawString(label5,largesia_x_tekstit,largesia_y_teksti(5));
  g.drawString(label6,largesia_x_tekstit,largesia_y_teksti(6));
  }
  
  /**largesia_y calculates the topLeftY value of the rectangle to be drawn
  *@param z - the z-th rectangle  
  */
  private int largesia_y(int z){
   return y+(z*brinja_e_katrorit)+(z*3);
  }
  
/**largesia_y_teksti calculates the topLeftY value of the text to be drawn
  *@param m - the m-th row of text  
  */
 private int largesia_y_teksti(int m){
   return largesia_y(m)+4*brinja_e_katrorit/5;
  }
  /**total calculates the sum of amounts given as parameters to the setSlice methods
  */
  private double total(){
  double totali=amount1+amount2+amount3+amount4+amount5+amount6;
  return totali;
  }
  
/**calculateArcAngle calculates the arc's angle
  *@param amount - the amount given as parameter to the setSlice methods
  */
  private double calculateArcAngle(double amount){
  return (amount*360)/total();
  }
  
/**calculateArcAngle calculates the arc's start angle
  *@param amount - the amount given as parameter to the setSlice methods
  */
  private double calculatestartAngle(double amount){
   totalStartAngle = totalStartAngle + calculateArcAngle(amount); 
   return totalStartAngle;
  }
/**setSlice1 draws the first slice of the chart
 *@param label - the string that is printed to the right of the pie
 *@param amount - the amount of the slice
 *@param C - the color in which the arc and rectangle is filled
 */
   public void setSlice1(String label,double amount,Color C){
  label1 =label;
  amount1 = amount;
  ngjyra1=C;
  this.repaint();
  }
  
/**setSlice2 draws the second slice of the chart*/ 
  public void setSlice2(String label,double amount,Color C){
  label2 =label;
  amount2=amount;
  ngjyra2=C;
  this.repaint();
  }
  
/**setSlice3 draws the third slice of the chart*/
  public void setSlice3(String label,double amount,Color C){
  label3 =label;
  amount3=amount;
  ngjyra3=C;
  this.repaint();
  }
 
/**setSlice4 draws the fourth slice of the chart*/ 
  public void setSlice4(String label,double amount,Color C){
  label4 =label;
  amount4=amount;
  ngjyra4=C;
  this.repaint();
  }
 
/**setSlice5 draws the fifth slice of the chart*/  
  public void setSlice5(String label,double amount,Color C){
  label5 =label;
  amount5=amount;
  ngjyra5=C;
  this.repaint();
  }
  
/**setSlice6 draws the sixth slice of the chart*/  
  public void setSlice6(String label,double amount,Color C){
  label6 =label;
  amount6=amount;
  ngjyra6=C;
  this.repaint();
  }
}